﻿using System;

class Program
{
    static void Main()
    {
        int numero, i, residuocontador;
        residuocontador = 0;

        Console.WriteLine("Ingrese un número entero no mayor a 6 cifras");
        numero = Convert.ToInt32(Console.ReadLine());

        if(numero > 99999)
        {
            Console.WriteLine("El número debe ser menor a 6 cifras, ingreselo de nuevo");
            return;
        }

        else
        {
            for(i=1; i<= numero; i++)
            {
                if(numero % i == 0)
                {
                    residuocontador = residuocontador +1;
                }
            }
            
            if (residuocontador == 2)
            {
                Console.WriteLine("El número que ingresó es primo");
            }

            else
            {
                Console.WriteLine("El número qie ingresó no es primo");
            }
        }
    }
}