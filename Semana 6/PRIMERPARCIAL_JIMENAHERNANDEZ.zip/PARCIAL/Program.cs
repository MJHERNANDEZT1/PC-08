﻿using System;

class Program
{
static void Main()
    {
        Console.Write("Ingrese el numero 1: ");
        int numero1 = Convert.ToInt32(Console.ReadLine());

        Console.Write("Ingrese el numero 2: ");
        int numero2 = Convert.ToInt32(Console.ReadLine());

        Console.Write("Ingrese el numero 3: ");
        int numero3 = Convert.ToInt32(Console.ReadLine());

    
        if (numero1 % 2 == 0)
        {
            Console.WriteLine($"El numero 1 ({numero1}) es par");
        }
        else
        {
            Console.WriteLine($"El numero 1 ({numero1}) es impar");
        }

        if (numero2 % 2 == 0)
        {
            Console.WriteLine($"El numero 2 ({numero2}) es par");
        }
        else
        {
            Console.WriteLine($"El numero 2 ({numero2}) es impar");
        }

        if (numero3 % 2 == 0)
        {
            Console.WriteLine($"El numero 3 ({numero3}) es par");
        }
        else
        {
            Console.WriteLine($"El numero 3 ({numero3}) es impar");
        }
    }
}